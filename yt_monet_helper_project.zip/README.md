# YT Monetization Helper (Starter Android Project)

This is a minimal Jetpack Compose Kotlin starter project for an app to help with YouTube monetization workflows.
It contains a single activity (MainActivity.kt) with the starter UI.

## How to build APK
1. Copy this folder to your development machine (or use Android Studio on Android via Termux+Android Studio is not recommended).
2. Open Android Studio (Electric Eel or newer).
3. Choose "Open" and select the folder `yt_monet_helper_project`.
4. Let Android Studio sync Gradle (it may prompt to update Gradle plugin/Gradle distribution).
5. Connect an Android device or use the emulator.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).
7. After build succeeds, locate the APK via the Build output or in `app/build/outputs/apk/`.

## Notes
- If prompted to update Gradle or plugins, accept recommended updates.
- This starter uses Kotlin + Jetpack Compose. For production, add Room, persistent storage, and polish UI.
- If you want, share how you'd like the app customized (colors, features) and I can update the project files.