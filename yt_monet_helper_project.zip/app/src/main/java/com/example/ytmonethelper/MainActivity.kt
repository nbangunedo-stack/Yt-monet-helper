package com.example.ytmonethelper

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        setContent {
            MonetHelperApp()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "YTMonetReminders"
            val desc = "Reminders for upload schedule"
            val channel = NotificationChannel("yt_monet_channel", name, NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = desc
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }
}

@Composable
fun MonetHelperApp() {
    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("YouTube Monetization Helper") }) }) {
            Column(Modifier.padding(16.dp)) {
                ChecklistSection()
                Spacer(modifier = Modifier.height(12.dp))
                IdeaGeneratorSection()
                Spacer(modifier = Modifier.height(12.dp))
                TitleTagGeneratorSection()
                Spacer(modifier = Modifier.height(12.dp))
                SchedulerSection()
            }
        }
    }
}

@Composable
fun ChecklistSection() {
    val prefs = LocalContext.current.getSharedPreferences("monet_prefs", Context.MODE_PRIVATE)
    val items = listOf(
        "1. 1,000 Subscribers",
        "2. 4,000 Watch Hours (last 12 months)",
        "3. No active copyright strikes",
        "4. Compliant content & ad-friendly",
        "5. Channel verified & 2FA enabled",
        "6. Consistent upload schedule"
    )
    Column {
        Text("Monetization Checklist", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(6.dp))
        items.forEachIndexed { idx, text ->
            var checked by remember { mutableStateOf(prefs.getBoolean("chk_$idx", false)) }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(
                    checked = checked,
                    onCheckedChange = {
                        checked = it
                        prefs.edit().putBoolean("chk_$idx", it).apply()
                    }
                )
                Text(text)
            }
        }
    }
}

@Composable
fun IdeaGeneratorSection() {
    val coastal = listOf("Coastal Night", "Shrimp Farm", "Beach Dawn", "Tidal Pool", "Aerator Close-up")
    val format = listOf("ASMR Short", "1-2 min Tutorial", "10+ min Ambient", "POV Repair", "Time-lapse")
    val concepts = listOf("Aerator sound + waves", "Panel repair POV", "Night patrol ambience", "Tool cleaning ASMR", "Waves + tool tapping")
    var idea by remember { mutableStateOf("Press GENERATE to get an idea") }
    Column {
        Text("Idea Generator", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(6.dp))
        Button(onClick = {
            val c = coastal.random()
            val f = format.random()
            val co = concepts.random()
            idea = "$c • $f • Concept: $co"
        }) { Text("GENERATE IDEA") }
        Spacer(Modifier.height(8.dp))
        Text(idea)
    }
}

@Composable
fun TitleTagGeneratorSection() {
    val context = LocalContext.current
    var seed by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }

    Column {
        Text("Title & Tag Generator", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = seed, onValueChange = { seed = it }, label = { Text("Keyword / Idea (e.g. 'aerator night')") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row {
            Button(onClick = {
                val base = if (seed.isBlank()) "Coastal Shrimp Farm ASMR" else seed.capitalizeWords()
                title = "$base — Relaxing Night Sounds (No Face)"
                desc = "Recorded at a real shrimp farm. Relax with coastal aerator sounds, waves, and gentle tools. Perfect for sleep & study.\n\nSubscribe for more coastal ASMR."
                tags = listOf("#ShrimpFarm","#Aquaculture","#ASMR","#WaterSounds","#CoastalLife").joinToString(" ")
            }) { Text("GENERATE") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                // copy title to clipboard
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("yt_title", title))
                android.widget.Toast.makeText(context, "Title copied", android.widget.Toast.LENGTH_SHORT).show()
            }) { Text("COPY TITLE") }
        }
        Spacer(Modifier.height(8.dp))
        Text("Title:", style = MaterialTheme.typography.subtitle1); Text(title)
        Spacer(Modifier.height(6.dp))
        Text("Description:", style = MaterialTheme.typography.subtitle1); Text(desc)
        Spacer(Modifier.height(6.dp))
        Text("Tags / Hashtags:", style = MaterialTheme.typography.subtitle1); Text(tags)
    }
}

fun String.capitalizeWords(): String = split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercaseChar() } }

@Composable
fun SchedulerSection() {
    val ctx = LocalContext.current
    val prefs = ctx.getSharedPreferences("monet_prefs", Context.MODE_PRIVATE)
    var scheduleText by remember { mutableStateOf(prefs.getString("next_schedule", "No schedule set") ?: "No schedule set") }

    Column {
        Text("Upload Scheduler", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(6.dp))
        Text("Next schedule: $scheduleText")
        Spacer(Modifier.height(8.dp))
        Row {
            Button(onClick = {
                // set reminder 1 minute from now (demo); in production, use DatePicker/TimePicker
                val cal = Calendar.getInstance().apply { add(Calendar.MINUTE, 1) }
                setReminder(ctx, cal.timeInMillis, "Time to record/upload your ASMR video!")
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                val formatted = fmt.format(Date(cal.timeInMillis))
                prefs.edit().putString("next_schedule", formatted).apply()
                scheduleText = formatted
            }) { Text("REMIND IN 1 MIN (DEMO)") }

            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                // export ideas to simple CSV saved to app files dir
                val csv = "idea,title,tags\n" +
                        "Aerator Night,\"Aerator Night ASMR\",\"#ShrimpFarm #ASMR\"\n"
                val file = java.io.File(ctx.filesDir, "export_ideas.csv")
                file.writeText(csv)
                android.widget.Toast.makeText(ctx, "Exported to ${file.absolutePath}", android.widget.Toast.LENGTH_LONG).show()
            }) { Text("EXPORT CSV") }
        }
    }
}

// --- Reminder helper using AlarmManager + simple BroadcastReceiver ---
fun setReminder(context: Context, whenMillis: Long, message: String) {
    val intent = Intent(context, ReminderReceiver::class.java).apply {
        putExtra("msg", message)
    }
    val pending = PendingIntent.getBroadcast(context, Random.nextInt(100000), intent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pending)
    } else {
        am.setExact(AlarmManager.RTC_WAKEUP, whenMillis, pending)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val msg = intent?.getStringExtra("msg") ?: "Reminder"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = Notification.Builder(context, "yt_monet_channel")
            .setContentTitle("YT Helper")
            .setContentText(msg)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        nm.notify(Random.nextInt(100000), notif)
    }
}