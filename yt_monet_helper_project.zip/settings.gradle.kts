rootProject.name = "YTMonetHelper"
include(":app")