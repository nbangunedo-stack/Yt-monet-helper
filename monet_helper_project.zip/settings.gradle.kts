rootProject.name = "MonetHelper"
include(":app")